## Índice de Afinidade Dinâmica (IAD)

Fórmula do enunciado:

```
              (HP × Fcat) + (Attack × Speed)
IAD_final = ( ───────────────────────────────  +  Weight ) × Mtipo
                (Defense + 1) × (Height + 1)
```

O `Weight` é **somado à fração** e **não faz parte do denominador**. O
denominador é apenas `(Defense + 1) × (Height + 1)`. Só depois de dividir é que
se soma o `Weight`, e o total é multiplicado pelo `Mtipo`. O resultado é
arredondado a exatamente 2 casas decimais.

## Nota sobre Height e Weight

Os valores de `height` e `weight` utilizados no cálculo do IAD correspondem aos
valores brutos fornecidos pela PokéAPI (`height` em decímetros e `weight` em
hectogramas), sem qualquer conversão de unidades.

As conversões para metros (m) e quilogramas (kg) são utilizadas apenas para
apresentação na interface da aplicação. Esta abordagem garante a consistência
entre os dados obtidos da API, os cálculos manuais e o valor do IAD apresentado.

Código-fonte: https://github.com/KennedySilva8907/pokedex-mca

Kennedy Silva (2025212)
Nikita Slobodeniuc (2025214)
Tiago Silva (2025536)
